drop table if exists ACT_ID_INFO cascade constraints;
drop table if exists ACT_ID_GROUP cascade constraints;
drop table if exists ACT_ID_MEMBERSHIP cascade constraints;
drop table if exists ACT_ID_USER cascade constraints;
